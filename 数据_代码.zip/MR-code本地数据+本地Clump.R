#安装所需R包，此代码仅在安装时运行一次，后续无需运行
install.packages("devtools")
install.packages("ggplot2")
devtools::install_github("MRCIEU/TwoSampleMR")

#清空环境，设置工作目录，载入所需R包
rm(list=ls())
setwd("C:\\Users\\Dany\\Desktop\\第8期课程资料准备\\不同格式数据")

library(TwoSampleMR)
library(ggplot2)
library(ieugwasr)

###第一步：读取暴露数据 ###
#方法2：自行读入下载好的GWAS summary数据，注意数据集中的列名与下面代码中的各指标对应进行修改，确保一致才行
exp_dat <- read_exposure_data(
  filename = "GCST90095034_buildGRCh37.tsv",  #数据可以是csv、tsv、txt格式均可
  sep = "\t", #如果是csv格式数据，\t需要更改为英文的逗号（,）
  snp_col = "variant_id",  #SNP列
  beta_col = "beta",
  se_col = "standard_error",
  effect_allele_col = "effect_allele",
  other_allele_col = "other_allele",
  eaf_col = "effect_allele_frequency",
  pval_col = "p_value",
  samplesize_col = "Samplesize"
)

#使用自己下载数据，需要提取与暴露相关的SNP，5e-8为标准
exp_dat <- exp_dat[exp_dat$pval.exposure < 5e-8,]



# 本地clump
# 首先定义本地clump函数的标准
clump_local <- function(dat,
                        plink_bin,
                        bfile,
                        clump_kb = 10000,
                        clump_r2 = 0.001,
                        clump_p = 1)
  
{
  d <- dat %>% dplyr::select(rsid = SNP, pval = pval.exposure,
                             id = id.exposure)
  out <- ieugwasr::ld_clump_local(
    d,
    plink_bin = plink_bin,
    bfile = bfile,
    clump_kb = clump_kb, clump_r2 = clump_r2,clump_p = clump_p
  )
  keep <- paste(dat$SNP,dat$id.exposure)%in% paste(out$rsid,out$id)
  return(dat[keep,])
}

# 调用先前定义的函数运行clump--欧洲人群
exp_dat<- clump_local(exp_dat,
                                   bfile="E:\\MR_Free\\clump\\bfile\\EUR", 
                                   plink_bin = "E:\\MR_Free\\clump\\plink\\plink_win64_20231018\\plink.exe")


# 调用先前定义的函数运行clump--亚洲人群
exp_dat<- clump_local(exp_dat,
                                   bfile="E:\\MR_Free\\clump\\bfile\\EAS", 
                                   plink_bin = "E:\\MR_Free\\clump\\plink\\plink_win64_20231018\\plink.exe")


###第二步：混杂因素筛选（Catalog网站、IEU网站、LDlink网站查询），筛选混杂后的csv文件命名为exp_dat02.csv

###第三步：计算每个SNP的工具变量F值，剔除弱工具变量（F值＜10的）
#用下面代码计算F值，并筛选
exp_dat$R2<-2*exp_dat$eaf.exposure*(1-exp_dat$eaf.exposure)*exp_dat$beta.exposure^2 #计算R2
exp_dat$F_sta<-(exp_dat$samplesize.exposure-2)*exp_dat$R2/(1-exp_dat$R2) #计算F值

exp_dat$F_sta<-(exp_dat$beta.exposure/exp_dat$se.exposure)^2 #另一种计算F值的代码，但eaf值缺失时使用
##根据F值>10，剔除SNP，代码如下
exp_dat<-subset(exp_dat,F_sta>10)
#确定删除的SNP（通常可筛选出的弱工具变量比较少），保存exp_dat03.csv文件
write.csv(exp_dat, file="exp_dat03.csv")

#运行下面一行代码，读取确定最终暴露SNP集
exp_dat <- read.csv(file="exp_dat03.csv",header = TRUE)


###第四步：提取本地结局数据 ###

#方法2：自行读入下载的GWAS summary数据
#以芬兰数据库为例，基本同暴露数据
out_dat <- read_outcome_data(
  snps = exp_dat$SNP,
  filename = "finngen_R10_I9_CHD.gz",  #可以直接读取芬兰数据的压缩包的，无需解压缩
  sep = "\t",
  snp_col = "rsids",
  beta_col = "beta",
  se_col = "sebeta",
  effect_allele_col = "alt",
  other_allele_col = "ref",
  eaf_col = "af_alt",
  pval_col = "pval")


###第五步：协调效应，合并数据###
dat <- harmonise_data(
  exposure_dat =  exp_dat, 
  outcome_dat = out_dat
)

#剔除与结局有关的SNP
dat <- subset(dat,dat$pval.outcome > 5e-8)
write.csv(dat, file="dat.csv")

###第六步：进行MR分析###默认是常用的5种方法，基本就够了
res <- mr(dat)

res
generate_odds_ratios(res) #OR值和置信区间计算

#查看MR的方法
mr_method_list()

#自选MR方法：IVW，mr-egger（方便后续绘图，也可以选择五种方法绘图），IVW法又分为fixed effect和random effect
##如果有异质性，可考虑选择random，如果没有异质性选择fixed，其实β值差别不会特别大
res1 <- mr(dat,method_list = c("mr_ivw_mre","mr_ivw_fe","mr_egger_regression"))
res1

#异质性检验
mr_heterogeneity(dat)

#跑离群值（速度慢，可以不做）
run_mr_presso(dat,NbDistribution = 10000)

##水平多效性检验
mr_pleiotropy_test(dat)

##获取单独的每个SNP的效应值
res_single <- mr_singlesnp(dat)
res_single

##留一法分析 Leave-one-out analysis
res_loo <- mr_leaveoneout(dat)
res_loo 

##散点图 
p1 <- mr_scatter_plot(res, dat)
p1[[1]]
ggsave(p1[[1]], file="p1_scatter_plot.pdf", width=7, height=7)


##森林图
p2 <- mr_forest_plot(res_single)
p2[[1]]
##保存图片
ggsave(p2[[1]], file="p2_forest_plot.pdf", width=7, height=7)


##留一法图 
p3 <- mr_leaveoneout_plot(res_loo)
p3[[1]]
##保存图片
ggsave(p3[[1]], file="p3_leaveoneout_plot.pdf", width=7, height=7)


##漏斗图 
res_single <- mr_singlesnp(dat)
p4 <- mr_funnel_plot(res_single)
p4[[1]]
##保存图片
ggsave(p4[[1]], file="p4_funnel_plot.pdf", width=7, height=7)